# movies/views.py
from django.shortcuts import render

def movie_list(request):
    # Static data for top Bollywood and Hollywood movies
    bollywood_movies = [
        {"title": "3 Idiots", "year": 2009, "rating": "8.4/10"},
        {"title": "Dangal", "year": 2016, "rating": "8.3/10"},
        {"title": "Sholay", "year": 1975, "rating": "8.2/10"},
    ]

    hollywood_movies = [
        {"title": "Inception", "year": 2010, "rating": "8.8/10"},
        {"title": "The Dark Knight", "year": 2008, "rating": "9.0/10"},
        {"title": "Forrest Gump", "year": 1994, "rating": "8.8/10"},
    ]

    # Pass the data to the template
    context = {
        'bollywood_movies': bollywood_movies,
        'hollywood_movies': hollywood_movies
    }
    
    return render(request, 'movies/movie_list.html', context)
